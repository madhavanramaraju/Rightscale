display_msg = "Test page creating..."
